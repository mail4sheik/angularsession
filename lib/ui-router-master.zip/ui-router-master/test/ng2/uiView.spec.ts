import "ui-router-ng2";

fdescribe("foo", () => {
  it("should work", () => {
    expect(true).toBeFalsy();
  });
});